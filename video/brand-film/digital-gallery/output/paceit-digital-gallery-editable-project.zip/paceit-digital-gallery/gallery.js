import * as THREE from 'three';
import {gsap} from 'gsap';
const W=1080,H=1920;
const renderer=new THREE.WebGLRenderer({canvas:document.querySelector('#film'),antialias:true,preserveDrawingBuffer:true});
renderer.setSize(W,H,false);renderer.setPixelRatio(1);renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.setClearColor('#191a1c');
const scene=new THREE.Scene();const camera=new THREE.PerspectiveCamera(40,W/H,.1,150);
const media={home:'assets/home.mp4',gallery:'assets/gallery.mp4',forme:'assets/forme-preview.mp4',soda:'assets/soda-preview.mp4',daylight:'assets/daylight.mp4',relay:'assets/relay.mp4',contact:'assets/contact.mp4',flow:'assets/flow-plumbing-demo.mp4'};
const videos={};const textures={};
for(const [id,src]of Object.entries(media)){const v=document.createElement('video');v.src=src;v.muted=true;v.playsInline=true;v.preload='auto';v.load();videos[id]=v;await new Promise((res,rej)=>{if(v.readyState>=2)res();else{v.addEventListener('loadeddata',res,{once:true});v.addEventListener('error',()=>rej(Error('Video load failed '+src)),{once:true})}});const t=new THREE.VideoTexture(v);t.colorSpace=THREE.NoColorSpace;t.minFilter=THREE.LinearFilter;t.magFilter=THREE.LinearFilter;textures[id]=t;}
for(const[id,src]of Object.entries({northstar:'assets/analytics-preview.webp',braai:'assets/daylight-preview.webp'})){textures[id]=await new THREE.TextureLoader().loadAsync(src);textures[id].colorSpace=THREE.NoColorSpace;}
// A restrained, fixed exhibition. Only the virtual camera moves.
const tiles=[
 ['braai',-1,4,'MR BRAAI GUY / QUOTATIONS'],['forme',0,4,'FORME / PORTFOLIO PREVIEW'],['daylight',1,4,'DAYLIGHT / CONCEPT'],
 ['soda',-1,3,'SODA / PORTFOLIO PREVIEW'],['relay',0,3,'RELAY / CONCEPT'],['home',1,3,'PACEIT / CURRENT WEBSITE'],
 ['northstar',-1,2,'NORTHSTAR / CONCEPT'],['forme',0,2,'FORME / PORTFOLIO PREVIEW'],['contact',1,2,'A CONVERSATION'],
 ['contact',-1,1,'A CONVERSATION'],['gallery',0,1,'SELECTED WORK'],['northstar',1,1,'DASHBOARD CONCEPT'],
 ['soda',-1,0,'SODA / PORTFOLIO PREVIEW'],['home',0,0,'PACEIT / CURRENT WEBSITE'],['braai',1,0,'MR BRAAI GUY / QUOTATIONS'],
 ['forme',-1,-1,'FORME / PORTFOLIO PREVIEW'],['soda',0,-1,'SODA / PORTFOLIO PREVIEW'],['northstar',1,-1,'NORTHSTAR / CONCEPT'],
 ['relay',-1,-2,'RELAY / INTERACTIVE CONCEPT'],['flow',0,-2,'FLOW / PRODUCT DEMO'],['daylight',1,-2,'DAYLIGHT / INTERACTIVE CONCEPT'],
 ['gallery',-1,-3,'PACEIT / SELECTED WORK'],['contact',0,-3,'YOUR NEXT PROJECT'],['braai',1,-3,'MR BRAAI GUY / WORKSPACE']
];
const sw=6.8,sh=4.78,sx=7.9,sy=5.9;
function rounded(w,h,r){const s=new THREE.Shape();s.moveTo(-w/2+r,-h/2);s.lineTo(w/2-r,-h/2);s.quadraticCurveTo(w/2,-h/2,w/2,-h/2+r);s.lineTo(w/2,h/2-r);s.quadraticCurveTo(w/2,h/2,w/2-r,h/2);s.lineTo(-w/2+r,h/2);s.quadraticCurveTo(-w/2,h/2,-w/2,h/2-r);s.lineTo(-w/2,-h/2+r);s.quadraticCurveTo(-w/2,-h/2,-w/2+r,-h/2);return new THREE.ShapeGeometry(s,16)}
// Soft contact shadows baked into a transparent texture, no glow.
const shadowCanvas=document.createElement('canvas');shadowCanvas.width=512;shadowCanvas.height=384;const c=shadowCanvas.getContext('2d');c.shadowColor='rgba(0,0,0,.85)';c.shadowBlur=30;c.shadowOffsetY=12;c.fillStyle='#000';c.beginPath();c.roundRect(42,40,428,294,18);c.fill();const shadowTexture=new THREE.CanvasTexture(shadowCanvas);
for(const[id,col,row,label]of tiles){const group=new THREE.Group();group.position.set(col*sx,row*sy,0);scene.add(group);
 const shadow=new THREE.Mesh(new THREE.PlaneGeometry(sw+1.3,sh+1.3),new THREE.MeshBasicMaterial({map:shadowTexture,transparent:true,depthWrite:false}));shadow.position.set(.05,-.10,-.10);group.add(shadow);
 const frame=new THREE.Mesh(rounded(sw+.10,sh+.10,.17),new THREE.MeshBasicMaterial({color:'#45494a'}));frame.position.z=-.02;group.add(frame);
 const texture=textures[id];const v=videos[id];const img=texture.image;const ar=v?v.videoWidth/v.videoHeight:img.width/img.height;
 const material=new THREE.ShaderMaterial({uniforms:{map:{value:texture},ratio:{value:ar},screenRatio:{value:sw/sh}},vertexShader:`varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,fragmentShader:`uniform sampler2D map;uniform float ratio;uniform float screenRatio;varying vec2 vUv;void main(){vec2 p=vUv;float aspect=ratio/screenRatio; if(aspect>1.)p.y=(p.y-.5)*aspect+.5;else p.x=(p.x-.5)/aspect+.5;vec3 color=vec3(.055,.061,.065);if(p.x>=0.&&p.x<=1.&&p.y>=0.&&p.y<=1.)color=texture2D(map,p).rgb;gl_FragColor=vec4(color,1.);}`.replace(';#include',';\n#include')});
 const geo=rounded(sw,sh,.14);const pos=geo.attributes.position;const uv=geo.attributes.uv;for(let i=0;i<uv.count;i++)uv.setXY(i,(pos.getX(i)+sw/2)/sw,(pos.getY(i)+sh/2)/sh);geo.attributes.uv.needsUpdate=true;
 group.add(new THREE.Mesh(geo,material));
 // Quiet exhibit labels are provenance, not marketing overlays.
 const lc=document.createElement('canvas');lc.width=1100;lc.height=64;const ctx=lc.getContext('2d');ctx.fillStyle='#a1a6a4';ctx.font='20px sans-serif';ctx.fillText(label,8,36);const lm=new THREE.Mesh(new THREE.PlaneGeometry(sw,.395),new THREE.MeshBasicMaterial({map:new THREE.CanvasTexture(lc),transparent:true,depthWrite:false}));lm.position.set(0,-sh/2-.28,0);group.add(lm);
}
const rig={x:0,y:4,z:54,rx:.015,ry:0,rz:-.015};const tl=gsap.timeline({paused:true});
const stops=[
 [2.65,{x:.65,y:1.8,z:39,rx:.025,ry:-.03,rz:-.018},'none'],
 [4.3,{x:0,y:0,z:18.9,rx:0,ry:0,rz:0},'power2.inOut'],
 [6.45,{x:.08,y:.10,z:18.3,rx:0,ry:0,rz:0},'none'],
 [7.25,{x:-2.7,y:-2,z:31,rx:.025,ry:.03,rz:.015},'power2.inOut'],
 [8.5,{x:-sx,y:-sy,z:19.2,rx:0,ry:0,rz:0},'power2.inOut'],
 [9.35,{x:-sx+.06,y:-sy+.04,z:18.9,rx:0,ry:0,rz:0},'none'],
 [10.45,{x:0,y:-sy,z:20.1,rx:0,ry:0,rz:0},'power2.inOut'],
 [11.3,{x:.08,y:-sy+.04,z:19.4,rx:0,ry:0,rz:0},'none'],
 [12.65,{x:sx,y:-sy*2,z:19.6,rx:0,ry:0,rz:0},'power2.inOut'],
 [14.15,{x:sx-.08,y:-sy*2+.06,z:19.1,rx:0,ry:0,rz:0},'none'],
 [15.35,{x:0,y:-sy*2,z:20,rx:0,ry:0,rz:0},'power2.inOut'],
 [15.95,{x:0,y:-sy*2,z:20.2,rx:0,ry:0,rz:0},'none'],
 [17.6,{x:0,y:-sy*.8,z:47,rx:.035,ry:-.03,rz:-.02},'power2.inOut'],
 [21,{x:.15,y:-sy*.75,z:48,rx:.035,ry:-.03,rz:-.02},'none']
];let prev=0;for(const[t,props,ease]of stops){tl.to(rig,{...props,duration:t-prev,ease},prev);prev=t;}
tl.to('#systems',{opacity:1,duration:.4},12.1).to('#systems',{opacity:0,duration:.35},15.5);
tl.to('#qualifier',{opacity:1,duration:.4},12.1).to('#qualifier',{opacity:0,duration:.35},15.5);
tl.to('#finish',{opacity:.82,duration:1.1,ease:'power2.inOut'},16.7);
tl.to('#closing',{opacity:1,y:0,duration:.85,ease:'power2.out'},17.4);
window.renderTime=async function(t){tl.time(t,false);await Promise.all(Object.entries(videos).map(async([id,v])=>{let offset=0;if(id==='home')offset=Math.max(0,t-2.7);else if(id==='forme')offset=4.2+(Math.max(0,t-6.8)%7.4);else if(id==='soda')offset=Math.max(0,t-8.8);else if(id==='daylight')offset=Math.max(0,t-11.2);else if(id==='flow')offset=8+Math.max(0,t-13.6);else offset=t*.55;const target=Math.min(Math.max(.02,offset%(v.duration-.1)),v.duration-.06);if(Math.abs(v.currentTime-target)>.009){await new Promise((resolve,reject)=>{const timeout=setTimeout(()=>reject(Error('Seek timeout '+id)),10000);v.addEventListener('seeked',()=>{clearTimeout(timeout);resolve()},{once:true});v.currentTime=target;});}textures[id].needsUpdate=true;}));camera.position.set(rig.x,rig.y,rig.z);camera.rotation.set(rig.rx,rig.ry,rig.rz);renderer.render(scene,camera);return {t,tiles:tiles.length,videos:Object.keys(videos).length};};
await document.fonts.ready;await window.renderTime(0);window.ready=true;
// Interactive edit/preview: ?preview=1. Space pauses; arrow keys scrub.
if(new URLSearchParams(location.search).has('preview')){let playing=true,time=0,last=performance.now();window.addEventListener('keydown',e=>{if(e.code==='Space')playing=!playing;if(e.code==='ArrowRight')time=Math.min(20.99,time+.5);if(e.code==='ArrowLeft')time=Math.max(0,time-.5)});async function tick(){const now=performance.now();if(playing)time=(time+(now-last)/1000)%21;last=now;await window.renderTime(time);requestAnimationFrame(tick)}tick();}
