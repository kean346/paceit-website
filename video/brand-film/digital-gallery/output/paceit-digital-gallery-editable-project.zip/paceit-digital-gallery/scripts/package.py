from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
root=Path(__file__).resolve().parents[1]
with ZipFile(root/'output/original-screen-recordings.zip','w',ZIP_DEFLATED,compresslevel=4) as z:
 for p in sorted((root/'recordings').glob('*.webm')):z.write(p,'recordings/'+p.name)
 z.write(root/'review/capture-manifest.json','capture-manifest.json')
with ZipFile(root/'output/paceit-digital-gallery-editable-project.zip','w',ZIP_DEFLATED,compresslevel=4) as z:
 for p in sorted(root.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(root)
  if any(part in ['node_modules','.cache','site-source','frames'] for part in rel.parts):continue
  if p.suffix=='.zip':continue
  if rel.parts[0]=='review' and p.suffix not in ['.json','.md','.jpg']:continue
  z.write(p,Path('paceit-digital-gallery')/rel)
for p in (root/'output').glob('*'):print(p.name,p.stat().st_size)
