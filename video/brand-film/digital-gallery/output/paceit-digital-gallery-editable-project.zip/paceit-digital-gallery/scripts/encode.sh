#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
ffmpeg -y -v warning -framerate 30 -i frames/%05d.png -i assets/original-score.wav -map 0:v -map 1:a -c:v libx264 -preset slow -crf 17 -pix_fmt yuv420p -profile:v high -level 4.1 -c:a aac -b:a 256k -ar 48000 -ac 2 -af 'loudnorm=I=-15:TP=-2.3:LRA=9' -t 21 -movflags +faststart output/paceit-digital-gallery-reel.mp4
