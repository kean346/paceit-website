"""Original 115 BPM instrumental. No samples or external music. CC0 for paceIT."""
import numpy as np, wave
from pathlib import Path
S=48000; DUR=21; N=S*DUR; mix=np.zeros((N,2),np.float64); rng=np.random.default_rng(472)
def put(x,start,vol=1,pan=0):
 i=int(start*S); x=np.asarray(x)*vol;n=min(len(x),N-i)
 if i<0 or n<=0:return
 mix[i:i+n,0]+=x[:n]*np.sqrt((1-pan)/2);mix[i:i+n,1]+=x[:n]*np.sqrt((1+pan)/2)
beat=60/115
for k in range(40):
 t0=k*beat
 if t0>19.3:break
 t=np.arange(int(.32*S))/S
 # Tuned soft kick; deliberately no repeated whoosh layer.
 f=47+100*np.exp(-t*42);x=np.sin(2*np.pi*np.cumsum(f)/S)*np.exp(-t*19)
 put(x,t0,.46)
 if k%2:
  t=np.arange(int(.09*S))/S;n=rng.normal(0,1,len(t));n=np.diff(n,prepend=0);put(n*np.exp(-t*74),t0,.035,.15)
 # restrained ticking metal, alternate velocities
 t=np.arange(int(.055*S))/S;put((np.sin(2*np.pi*6200*t)+.5*np.sin(2*np.pi*8341*t))*np.exp(-t*105),t0+beat/2,.028 if k%2 else .018,-.3)
 # warm syncopated sub line D minor / Bb / F / C
 notes=[73.416,58.27,87.307,65.406];freq=notes[(k//8)%4];t=np.arange(int(.41*S))/S
 env=np.minimum(t/.012,1)*np.exp(-t*7);bass=(np.sin(2*np.pi*freq*t)+.18*np.sin(4*np.pi*freq*t))
 put(bass*env,t0+beat*.46,.17)
# Airy restrained dyads, struck rather than cinematic sweeps
notes=[293.665,349.228,440,523.251,440,349.228,261.626,329.628]
for k in range(32):
 start=k*beat*1.0+.12;t=np.arange(int(1.1*S))/S;freq=notes[k%8]
 x=(np.sin(2*np.pi*freq*t)+.26*np.sin(2*np.pi*freq*2.002*t))*np.minimum(t/.006,1)*np.exp(-t*5.5)
 put(x,start,.055,(-.55 if k%2 else .55));put(x,start+.26,.018,(.55 if k%2 else -.55))
# Beat-aligned rounded tonal punctuation at scene arrivals
for at,f in [(3.13,587.33),(7.3,440),(9.91,659.25),(12,349.23),(16.7,293.665)]:
 t=np.arange(int(.55*S))/S;put(np.sin(2*np.pi*f*t)*np.minimum(t/.004,1)*np.exp(-t*10),at,.07)
# Final D minor chord resolves over the end card.
t=np.arange(int(3.1*S))/S
for f in [146.832,220,293.665,349.228]:
 put(np.sin(2*np.pi*f*t)*np.minimum(t/.22,1)*np.exp(-t*1.3),17.65,.065)
fade=np.minimum(np.arange(N)/S/.15,1)*np.clip((DUR-np.arange(N)/S)/.9,0,1);mix*=fade[:,None]
mix=np.tanh(mix*1.3);mix*=.82/max(np.max(np.abs(mix)),.82)
path=Path(__file__).resolve().parents[1]/'assets/original-score.wav'
with wave.open(str(path),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(S);w.writeframes((mix*32767).astype('<i2').tobytes())
print(path)
