# The Digital Gallery — editorial decisions

21 seconds, 30 fps. A charcoal exhibition of actual portfolio media and freshly captured interfaces. The floating rounded screens form a fixed three-column grid; rows continue past the camera. There is no opening title or logo.

Camera progression: a gently oblique full-grid drift → a controlled dolly toward the current dot-matrix homepage → pullback and lateral travel through Forme and Soda → Daylight's genuine appointment-selection interaction and the existing Flow product demo → wide final reveal.

The exhibition architecture is new video-production artwork. The screen content is not redesigned. Native aspect ratios are retained inside rounded frames, and in-screen motion is decoded from authentic recordings. Focus shots straighten toward the selected interface rather than spinning the screen.

Type is the website's locally hosted Plus Jakarta Sans with Space Grotesk for the final understated paceIT treatment. Green is limited to the brand. The only supporting sentence is “More than websites.” Concepts remain visibly identified through exhibit captions and a sample-data line.

Sound: an original 115 BPM composition with soft tuned kick, syncopated bass, sparse metallic ticks and airy struck dyads. Five short tonal cues support focus changes. No repeated broadband swishes, commercial song or stock music.

Closing CTA and URL stay inside the central area of the vertical frame. The cover uses the closing gallery composition. Screens remain readable through focused close-ups; fine interface details are naturally smaller in the opening exhibition shot.

## Provenance limitation

The managed network denied CONNECT to paceit.co.za. The captures use an unmodified local production build of the latest GitHub main revision b02b6ea4ef2fdf2d8df522c99ad188adf6442768. This distinction is intentional and documented; the live deployment could not be independently compared. Remote service video hosts were also unavailable, so those visual assets were not substituted with invented scenes.
