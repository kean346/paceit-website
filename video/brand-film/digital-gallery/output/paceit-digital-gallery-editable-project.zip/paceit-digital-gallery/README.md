# paceIT — The Digital Gallery

Standalone 21-second Instagram Reel production. Website files are read-only.

## Deliverables

- `output/paceit-digital-gallery-reel.mp4` — 1080×1920, 30 fps, H.264 + AAC stereo.
- `output/paceit-digital-gallery-cover.png` — 1080×1920 cover.
- `recordings/` — fresh, unedited Playwright screen recordings.
- `gallery.html`, `gallery.js` — editable Three.js gallery and GSAP camera timeline.
- `scripts/audio.py` — original 115 BPM instrumental synthesis; no commercial samples.
- `review/` — provenance, frames, full-film contact sheet and technical QC.

## Source and authenticity

Fresh captures come from the unchanged latest `origin/main` code, revision recorded in `review/capture-manifest.json`. The live domain was attempted but is blocked by this managed environment's HTTP policy (CONNECT 403). This is a local production build of the current repository, not an old recording; live-deployment equivalence could not be verified. No production website was modified or deployed.

The homepage is the current dot-matrix “Connecting / Your business” design. Soda and Forme are the videos currently included in the site's Selected Work gallery. Northstar is a dashboard concept. Daylight and Relay are interactive concepts with fictional local sample data. Flow is the existing product demonstration with fictional data. Mr Braai Guy is the current repository's dashboard preview image. These are presented as portfolio previews, concepts and demonstrations; the film makes no completed-client claims. No external stock websites or invented UI were created.

The shadow, screen frames and virtual camera are presentation layers only. Captured screens keep their native aspect ratios. Website interaction recordings retain their original UI.

## Reproduce

Requires Node.js, Chromium at `/usr/bin/chromium`, FFmpeg and Python with NumPy.

1. `npm ci --cache .cache/npm`
2. To recapture: export current main into `site-source/`, install its own dependencies, build and start at port 3040. Run `npm run capture`. Playwright requires its FFmpeg runtime; this workspace uses a local link to system FFmpeg under `.cache/browsers/ffmpeg-1011` and `PLAYWRIGHT_BROWSERS_PATH` pointing there.
3. `node scripts/prepare.cjs` trims only page-loading/setup from working copies; original WebMs remain intact.
4. `npm run audio`
5. `node scripts/render.cjs --stills` for review, or `npm run render` for all 630 deterministic frames.
6. `bash scripts/encode.sh`
7. `npm run verify`

`node scripts/server.cjs` opens the editable preview at `http://localhost:3050/?preview=1`. Space pauses. Left/right arrows scrub. Camera keyframes and in-screen video timing are in `gallery.js`. Composition is 3 columns × 8 rows; ten distinct captured/portfolio sources, with deliberate peripheral repeats. Change only these isolated production files.

Audio is an original synthesized instrumental created for this film. The composition and recording may be used by paceIT in promotional posts without additional music licensing. No third-party samples or commercial song recordings are used. Dependency/font licenses remain with their respective packages; Jakarta and Space Grotesk use the SIL Open Font License.
